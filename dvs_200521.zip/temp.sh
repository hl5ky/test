#!/bin/bash

DVS="/usr/local/dvs/"
AB="/opt/Analog_Bridge/"
MB="/opt/MMDVM_Bridge/"

#temp=$(vcgencmd measure_temp)
temp=$(cat /sys/class/thermal/thermal_zone0/temp)
temp=$(($temp/1000))
${MB}dvswitch.sh message "CPU temp = ${temp}'C"


