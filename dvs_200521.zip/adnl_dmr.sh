#!/bin/bash
#
#===================================
# Initial Configuration
# May. 16, 2020
# HL5KY
#===================================

#===================================
DVS="/usr/local/dvs/"
AB="/opt/Analog_Bridge/"
MB="/opt/MMDVM_Bridge/"

source ${DVS}var.txt
source ${DVS}lan/language.txt

#======= MAIN =================================================================================

if (whiptail --title " DMR Networks " --yesno "\
                   Setup for TGIF and DMRPlus\n
                       <Yes> to continue\
" 10 70); then :
	else ${DVS}adv_config_menu.sh; exit 0
fi

tgif_address=$(whiptail --title "Input" --inputbox "IP or DNS of TGIF Server" 10 60 ${tgif_address} 3>&1 1>&2 2>&3)
if [ $? != 0 ]; then ${DVS}adv_config_menu.sh; exit 0
fi

tgif_password=$(whiptail --title "Input" --inputbox "Password of TGIF Server" 10 60 ${tgif_password} 3>&1 1>&2 2>&3)
if [ $? != 0 ]; then ${DVS}adv_config_menu.sh; exit 0
fi

dmrplus_address=$(whiptail --title "Input" --inputbox "IP or DNS of DMRPlus Server" 10 60 ${dmrplus_address} 3>&1 1>&2 2>&3)
if [ $? != 0 ]; then ${DVS}adv_config_menu.sh; exit 0
fi

dmrplus_password=$(whiptail --title "Input" --inputbox "Password of DMRPlus Server" 10 60 ${dmrplus_password} 3>&1 1>&2 2>&3)
if [ $? != 0 ]; then ${DVS}adv_config_menu.sh; exit 0
fi


for file in ${DVS}var.txt
do
        sudo sed -i -e "/^tgif_address=/ c tgif_address=\"${tgif_address}\"" "${file}"
        sudo sed -i -e "/^tgif_password=/ c tgif_password=\"${tgif_password}\"" "${file}"
        sudo sed -i -e "/^dmrplus_address=/ c dmrplus_address=\"${dmrplus_address}\"" "${file}"
        sudo sed -i -e "/^dmrplus_password=/ c dmrplus_password=\"${dmrplus_password}\"" "${file}"
done


clear
if (whiptail --title " DMR Servers Setup Finished " --yesno "\
                   DMR Servers Setup Finished\n
                         <Yes> to MENU\
" 10 70); then :
fi

${DVS}adv_config_menu.sh;
exit 0
