
#!/bin/bash

DVS="/usr/local/dvs/"
AB="opt/Analog_Bridge/"
MB="/opt/MMDVM_Bridge/"

source ${DVS}lan/language.txt

#--------------------------------------------------------

do_english() {
sudo \cp -f ${DVS}lan/english.txt ${DVS}lan/language.txt
}
do_korean() {
sudo \cp -f ${DVS}lan/korean.txt ${DVS}lan/language.txt
}


#==== MIN_MENU ==========================================

OPTION=$(whiptail --title " Language " --menu "\
" 15 38 2 \
1 "English" \
2 "Korean" 3>&1 1>&2 2>&3)

if [ $? != 0 ]; then
        ${DVS}baseline_config_menu.sh; exit 0
fi

case $OPTION in
1)
${DVS}baseline_config_menu.sh; exit 0 ;;
#do_englsih ;;
2)
${DVS}baseline_config_menu.sh; exit 0 ;;
#do_korean ;;

esac

clear

${DVS}baseline_config_menu.sh; exit 0

exit 0




