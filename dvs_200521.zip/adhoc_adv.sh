#!/bin/bash

#===================================
# Created May. 5 2020
# By HL5KY
#===================================
DVS="/usr/local/dvs/"
AB="/opt/Analog_Bridge/"
MB="/opt/MMDVM_Bridge/"

source ${DVS}var.txt
source ${DVS}lan/language.txt


#------ do_restart_service() -----------------------------------------------------
do_restart_service() {

clear
echo
echo
echo "          ----------------------------------"
echo
echo "              DVSwitch Services Restarting"
echo
sleep 1
echo
echo
echo
echo "              Finished,  Back to the MENU"
echo
echo "                       QRX one"
echo "====================================================="
echo
${DVS}88_restart.sh
}

#------ do_change_to_basic() ----------------------------------------------------------
do_change_to_basic() {
# if there is dvsm.basic, Advanced macro is being used.
if [ -e ${AB}dvsm.basic ]; then
	sudo \mv -f ${AB}mainmenu.txt ${DVS}ab/
        sudo \mv -f ${AB}SB_audio.txt ${DVS}ab/
        sudo \mv -f ${AB}SB_dmr.txt ${DVS}ab/
        sudo \mv -f ${AB}SB_temp.txt ${DVS}ab/
        sudo \mv -f ${AB}SB_sys.txt ${DVS}ab/
        sudo \mv -f ${AB}TX_gain.txt ${DVS}ab/
        sudo \mv -f ${AB}RX_gain.txt ${DVS}ab/
        sudo \mv -f ${AB}extra_1.txt ${DVS}ab/
        sudo \mv -f ${AB}extra_2.txt ${DVS}ab/
        sudo \mv -f ${AB}extra_3.txt ${DVS}ab/
        sudo \mv -f ${AB}extra_4.txt ${DVS}ab/
        sudo \mv -f ${AB}extra_5.txt ${DVS}ab/
        sudo \mv -f ${AB}dvsm.macro ${DVS}ab/
        sudo \mv -f ${AB}dvsm.sh ${DVS}ab/
        sudo mv ${AB}dvsm.basic ${AB}dvsm.macro
#                sudo service cron stop
#                crontab -l | perl -nle 's/^([^#])/# $1/;print' | crontab
#                ${DVS}./88_restart.sh
for file in ${AB}Analog_Bridge.ini
        do
        sudo sed -i -e "/^usrpAudio/ c usrpAudio = AUDIO_UNITY                  ; Digital -> Analog (AUDIO_UNITY, AUDIO_USE_GAIN, AUDIO_USE_AGC)" "$file"
        sudo sed -i -e "/^usrpGain/ c usrpGain = ${usrpGain_default}                         ; Gain factor when usrpAudio = AUDIO_USE_GAIN (0.0 to 5.0) (1.0 = AUDIO_UNITY)" "$file"
        sudo sed -i -e "/^tlvAudio/ c tlvAudio = AUDIO_UNITY                  ; Analog -> Digital (AUDIO_UNITY, AUDIO_USE_GAIN, AUDIO_BPF)" "$file"
        sudo sed -i -e "/^tlvGain/ c tlvGain = ${txgain_dmr_default}                          ; Gain factor when tlvAudio = AUDIO_USE_GAIN (0.0 to 5.0) (1.0 = AUDIO_UNITY)" "$file"
	done
fi

whiptail --msgbox "\

All macro files were changed back to the basic which is DVSwitch default macro.

" 10 70 1

${DVS}adv_config_menu.sh; exit 0
#${DVS}adhoc_check.sh; exit 0
}

#------ MAIN---------------------------------------------------------------------------------------

OPTION=$(whiptail --title " Adhoc Menu & Macro " --menu "\
                 <ADVANCED>\n
       SAVE  : Ctrl-X >> Y >> Enter
       CANCEL: Ctrl-X >> N
----------------------------------------------
       To apply editing, <Restart DVSwitch>
" 31 50 17 \
1 "Edit <ADVANCED> dvsm.macro" \
2 "Edit dvsm.sh" \
3 "Edit  mainmenu.txt" \
4 "Edit  SB_audio.txt" \
5 "Edit    SB_dmr.txt" \
6 "Edit   SB_temp.txt" \
7 "Edit    SB_sys.txt" \
8 "Edit   TX_gain.txt" \
9 "Edit   RX_gain.txt" \
10 "Edit   extra_1.txt" \
11 "Edit   extra_2.txt" \
12 "Edit   extra_3.txt" \
13 "Edit   extra_4.txt" \
14 "Edit   extra_5.txt" \
15 "Restart DVSwitch Services" \
16 "Change to <BASIC> dvsm.macro" \
17 "Back to Advanced Configuration" 3>&1 1>&2 2>&3)

if [ $? != 0 ]; then ${DVS}adv_config_menu.sh
fi

case $OPTION in
1)
sudo nano ${AB}dvsm.macro; ${DVS}adhoc_adv.sh ;;
2)
sudo nano ${AB}dvsm.sh ; ${DVS}adhoc_adv.sh ;;
3)
sudo nano ${AB}mainmenu.txt; ${DVS}adhoc_adv.sh ;;
4)
sudo nano ${AB}SB_audio.txt; ${DVS}adhoc_adv.sh ;;
5)
sudo nano ${AB}SB_dmr.txt; ${DVS}adhoc_adv.sh ;;
6)
sudo nano ${AB}SB_temp.txt; ${DVS}adhoc_adv.sh ;;
7)
sudo nano ${AB}SB_sys.txt; ${DVS}adhoc_adv.sh ;;
8)
sudo nano ${AB}TX_gain.txt; ${DVS}adhoc_adv.sh ;;
9)
sudo nano ${AB}RX_gain.txt; ${DVS}adhoc_adv.sh ;;
10)
sudo nano ${AB}extra_1.txt; ${DVS}adhoc_adv.sh ;;
11)
sudo nano ${AB}extra_2.txt; ${DVS}adhoc_adv.sh ;;
12)
sudo nano ${AB}extra_3.txt; ${DVS}adhoc_adv.sh ;;
13)
sudo nano ${AB}extra_4.txt; ${DVS}adhoc_adv.sh ;;
14)
sudo nano ${AB}extra_5.txt; ${DVS}adhoc_adv.sh ;;
15)
do_restart_service; ${DVS}adhoc_adv.sh ;;
16)
do_change_to_basic ;;
17)
${DVS}adv_config_menu.sh; exit 0 ;;
esac

#------ END of MAIN ---------------------------------------------------------------------------------------
fi

clear

exit 0
