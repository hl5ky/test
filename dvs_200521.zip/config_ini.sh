#!/bin/bash

#===================================
# May. 9, 2020
# HL5KY
#===================================
DVS="/usr/local/dvs/"
AB="/opt/Analog_Bridge/"
MB="/opt/MMDVM_Bridge/"

source ${DVS}lan/language.txt


OPTION=$(whiptail --title " Configure ini. files " --menu "\
\n
      SAVE  : Ctrl-X >> Y >> Enter
      CANCEL: Ctrl-X >> N
" 20 43 9 \
1 "Edit Analog_Bridge.ini" \
2 "Edit MMDVM_Bridge.ini" \
3 "Edit NXDNGateway.ini" \
4 "Edit P25Gateway.ini" \
5 "Edit YSFGateway.ini" \
6 "Edit ircddbgateway" \
7 "Edit DVSwitch.ini" \
8 "Back"  3>&1 1>&2 2>&3)

if [ $? != 0 ]; then ${DVS}adv_config_menu.sh; exit 0
fi

case $OPTION in
1)
sudo nano /opt/Analog_Bridge/Analog_Bridge.ini; ${DVS}config_ini.sh ;;
2)
sudo nano /opt/MMDVM_Bridge/MMDVM_Bridge.ini; ${DVS}config_ini.sh ;;
3)
sudo nano /opt/NXDNGateway/NXDNGateway.ini; ${DVS}config_ini.sh ;;
4)
sudo nano /opt/P25Gateway/P25Gateway.ini; ${DVS}config_ini.sh ;;
5)
sudo nano /opt/YSFGateway/YSFGateway.ini; ${DVS}config_ini.sh ;;
6)
sudo nano /etc/ircddbgateway; ${DVS}config_ini.sh ;;
7)
sudo nano /opt/MMDVM_Bridge/DVSwitch.ini; ${DVS}config_ini.sh ;;
8)
sudo ${DVS}adv_config_menu.sh; exit 0

esac

clear

exit 0
