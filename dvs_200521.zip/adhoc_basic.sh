#!/bin/bash

#===================================
# Created May. 5 2020
# By HL5KY
#===================================
DVS="/usr/local/dvs/"
AB="/opt/Analog_Bridge/"
MB="/opt/MMDVM_Bridge/"

source ${DVS}lan/language.txt
source ${DVS}var.txt


#------ do_restart_service() -----------------------------------------------------
do_restart_service() {

clear
echo
echo
echo "          ----------------------------------"
echo
echo "              DVSwitch Services Restarting"
echo
sleep 1
echo
echo
echo
echo "              Finished,  Back to the MENU"
echo
echo "                       QRX one"
echo "====================================================="
echo
${DVS}88_restart.sh
}

#------ do_change_to_adv() ----------------------------------------------------------
do_change_to_adv() {
# if there is not dvsm.basic, Basic macro is being used
if [ ! -e ${AB}dvsm.basic ]; then
	sudo mv ${AB}dvsm.macro ${AB}dvsm.basic
	sudo cp ${DVS}ab/*.* ${AB}
#                crontab -l | perl -nle 's/^#\s*([0-9*])/$1/;print' | crontab
#                sudo service cron restart
#                ${DVS}./88_restart.sh
for file in ${AB}Analog_Bridge.ini
        do
	sudo sed -i -e "/^usrpAudio/ c usrpAudio = AUDIO_USE_GAIN              ; Digital -> Analog (AUDIO_UNITY, AUDIO_USE_GAIN, AUDIO_USE_AGC)" "$file"
        sudo sed -i -e "/^usrpGain/ c usrpGain = ${usrpGain}                         ; Gain factor when usrpAudio = AUDIO_USE_GAIN (0.0 to 5.0) (1.0 = AUDIO_UNITY)" "$file"
        sudo sed -i -e "/^tlvAudio/ c tlvAudio = AUDIO_USE_GAIN               ; Analog -> Digital (AUDIO_UNITY, AUDIO_USE_GAIN, AUDIO_BPF)" "$file"
        sudo sed -i -e "/^tlvGain/ c tlvGain = ${txgain_dmr}                          ; Gain factor when tlvAudio = AUDIO_USE_GAIN (0.0 to 5.0) (1.0 = AUDIO_UNITY)" "$file"
	done
fi

whiptail --msgbox "\

All macro files were changed to the Advanced macro.

" 10 70 1

${DVS}adhoc_check.sh; exit 0
}

#------ MAIN---------------------------------------------------------------------------------------

if (whiptail --title " BASIC Macro Configuration " --yesno "\
You are using BASIC Macro Configuration

Do you want to change to Advanced Macro Configuration ?

<Yes> to Continue, <No> to Cancel
" 12 70); then do_change_to_adv
fi

if [ $? != 0 ]; then ${DVS}}adv_config_menu.sh; exit 0
fi


#OPTION=$(whiptail --title " Adhoc Menu & Macro " --menu "\
#                <BASIC>\n
#. SAVE  : Ctrl-X >> Y >> Enter           \
# . CANCEL: Ctrl-X >> N                   \
#-----------------------------------------\
#. To apply editing, <Restart DVSwitch>   \
#" 28 45 14 \
#1 "Edit <BASIC> dvsm.macro" \
#2 "Edit 00.txt" \
#3 "Edit 01.txt" \
#4 "Edit 02.txt" \
#5 "Edit 03.txt" \
#6 "Edit 04.txt" \
#7 "Edit 05.txt" \
#8 "Edit 06.txt" \
#9 "Edit 07.txt" \
#10 "Edit 08.txt" \
#11 "Edit 09.txt" \
#12 "Restart DVSwitch Services" \
#13 "Change to <ADVANCED> dvsm.macro" \
#14 "Back" 3>&1 1>&2 2>&3)

#if [ $? != 0 ]; then ${DVS}adv_config.sh
#fi

#case $OPTION in
#1)
#sudo nano ${AB}dvsm.macro; ${DVS}adhoc_basic.sh ;;
#2)
#sudo nano ${AB}0.txt; ${DVS}adhoc_basic.sh ;;
#3)
#sudo nano ${AB}1.txt; ${DVS}adhoc_basic.sh ;;
#4)
#5udo nano ${AB}2.txt; ${DVS}adhoc_basic.sh ;;
#6)
#sudo nano ${AB}3.txt; ${DVS}adhoc_basic.sh ;;
#7)
#sudo nano ${AB}4.txt; ${DVS}adhoc_basic.sh ;;
#8)
#sudo nano ${AB}5.txt; ${DVS}adhoc_basic.sh ;;
#9)
#sudo nano ${AB}6.txt; ${DVS}adhoc_basic.sh ;;
#10)
#sudo nano ${AB}7.txt; ${DVS}adhoc_basic.sh ;;
#10)
#sudo nano ${AB}8.txt; ${DVS}adhoc_basic.sh ;;
#11)
#sudo nano ${AB}9.txt; ${DVS}adhoc_basic.sh ;;
#12)
#do_restart_service; ${DVS}adhoc_basic.sh ;;
#13)
#do_change_to_adv ;;
#14)
#${DVS}adv_config.sh; exit 0 ;;
#esac

#------ END of MAIN ---------------------------------------------------------------------------------------

clear

${DVS}adv_config_menu.sh

exit 0
