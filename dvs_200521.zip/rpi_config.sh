#!/bin/bash

DVS="/usr/local/dvs/"
AB="/opt/Analog_Bridge/"
MB="/opt/MMDVM_Bridge/"

INTERACTIVE=True
ASK_TO_REBOOT=0
BLACKLIST=/etc/modprobe.d/raspi-blacklist.conf
CONFIG=/boot/config.txt

USER=${SUDO_USER:-$(who -m | awk '{ print $1 }')}



#-------------------------------------------------------------------------------------
do_change_timezone() {
  if [ "$INTERACTIVE" = True ]; then
    sudo dpkg-reconfigure tzdata
  else
    local TIMEZONE="$1"
    if [ ! -f "/usr/share/zoneinfo/$TIMEZONE" ]; then
      return 1;
    fi
    rm /etc/localtime
    echo "$TIMEZONE" > /etc/timezone
    dpkg-reconfigure -f noninteractive tzdata
  fi

localtime=$(date)

whiptail --msgbox "\
                       Your Local Time is

                 ${localtime}

" 10 70 1
${DVS}rpi_config.sh; exit 0
}
#-------------------------------------------------------------------------------------
do_wifi() {

ssid=$(whiptail --title " INPUT " --inputbox "enter SSID" 10 60 3>&1 1>&2 2>&3)
if [ $? != 0 ]; then ${DVS}rpi_config.sh; exit 0
fi
#
pswd=$(whiptail --title " INPUT " --inputbox "enter password" 10 60 3>&1 1>&2 2>&3)
if [ $? != 0 ]; then ${DVS}rpi_config.sh; exit 0
fi
#

rfkill unblock wifi

    IFS="/"
    value=$(cat /usr/share/zoneinfo/iso3166.tab | tail -n +26 | tr '\t' '/' | tr '\n' '/')
#    value=$(cat /usr/share/zoneinfo/iso3166.tab)
    country=$(whiptail --menu "Select the country code for wi-fi" 35 55 25 ${value} 3>&1 1>&2 2>&3)
    IFS=$oIFS

if (whiptail --title " wifi Setup " --yesno "\
           SSID = ${ssid}

           Password = ${pswd}

           Country Code = ${country}



            <Yes> to Continue, <No> to Cancel

" 16 70); then :
	else ${DVS}rpi_config.sh; exit 0
	if [ $? != 0 ]; then ${DVS}rpi_config.sh; exit 0
	fi
fi

# if there is character "country" in wpa_supplicant.conf
char=$(sudo grep -o "country" /etc/wpa_supplicant/wpa_supplicant.conf | wc -w)

if [ $((char)) -gt 0 ];
then
	for file in /etc/wpa_supplicant/wpa_supplicant.conf
	do
        	sudo sed -i -e "/country/ c country=\"${country}\"" "$file"
	        sudo sed -i -e "/ssid/ c \        ssid=\"${ssid}\"" "$file"
        	sudo sed -i -e "/psk/ c \        psk=\"${pswd}\"" "$file"
	done

else
	for file in /etc/wpa_supplicant/wpa_supplicant.conf
	do
                echo " " | sudo tee -a "$file"
		echo "country=${country}" | sudo tee -a "$file"
                echo "network={" | sudo tee -a "$file"
                echo "        ssid=${ssid}" | sudo tee -a "$file"
                echo "        psk=${pswd}" | sudo tee -a "$file"
                echo "}" | sudo tee -a "$file"
	done
fi
${DVS}rpi_config.sh; exit 0
}
#-------------------------------------------------------------------------------------
do_change_locale() {
  if [ "$INTERACTIVE" = True ]; then
    sudo dpkg-reconfigure locales
  else
    local LOCALE="$1"
    if ! LOCALE_LINE="$(grep "^$LOCALE " /usr/share/i18n/SUPPORTED)"; then
      return 1
    fi
    local ENCODING="$(echo $LOCALE_LINE | cut -f2 -d " ")"
    echo "$LOCALE $ENCODING" > /etc/locale.gen
    sed -i "s/^\s*LANG=\S*/LANG=$LOCALE/" /etc/default/locale
    dpkg-reconfigure -f noninteractive locales
  fi
${DVS}rpi_config.sh; exit 0
}
#-------------------------------------------------------------------------------------
do_configure_keyboard() {
  printf "Reloading keymap. This may take a short while\n"
  if [ "$INTERACTIVE" = True ]; then
    sudo dpkg-reconfigure keyboard-configuration
  else
    local KEYMAP="$1"
    sed -i /etc/default/keyboard -e "s/^XKBLAYOUT.*/XKBLAYOUT=\"$KEYMAP\"/"
    sudo dpkg-reconfigure -f noninteractive keyboard-configuration
  fi
  sudo invoke-rc.d keyboard-setup start
  sudo setsid sh -c 'exec setupcon -k --force <> /dev/tty1 >&0 2>&1'
  sudo udevadm trigger --subsystem-match=input --action=change
${DVS}rpi_config.sh; exit 0
}
#-------------------------------------------------------------------------------------
clear

OPTION=$(whiptail --title " Raspberry Pi Configuration " --menu "\
\n
" 13 90 5 \
"1 Setup Wi-Fi" "Enter SSID, pass-phrase and Change WiFi channels" \
"2 Change Locale" "Set language and regional settings"  \
"3 Change Timezone" "Set user's timezone" \
"4 Change Keyboard Layout" "Set layout for user's keyboard" \
"5 Back" "Back to Baseline Configuration"  3>&1 1>&2 2>&3)

case "$OPTION" in
1\ *) do_wifi ;;
2\ *) do_change_locale ;;
3\ *) do_change_timezone ;;
4\ *) do_configure_keyboard ;;
5\ *) ${DVS}baseline_config_menu.sh; exit 0 ;;
esac

clear

${DVS}baseline_config_menu.sh; exit 0

exit 0
