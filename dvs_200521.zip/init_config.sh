#!/bin/bash
#
#===================================
# Initial Configuration
# May. 18, 2020
# HL5KY
#===================================

#===================================
CRNT_DIR=`pwd`
DVS="/usr/local/dvs/"
AB="/opt/Analog_Bridge/"
MB="/opt/MMDVM_Bridge/"

source ${DVS}var.txt
source ${DVS}lan/language.txt
source ${DVS}bm.data

#--------------------------------------------------------------------------------------------------
do_change() {
echo
echo
echo "====================================================="
echo "              Processing Initial Configuration"
echo
echo "               QRX for a second . . . . . . "
echo
echo "      -----------------------------------------"
#-----------------------------------------------------------
analog="/opt/Analog_Bridge/"
for file in ${analog}Analog_Bridge.ini
do
	sudo sed -i -e "/^useEmulator =/ c useEmulator = true                      ; Use the MD380 AMBE emulator for AMBE72 (DMR/YSFN/NXDN)" "$file"
	sudo sed -i -e "/^gatewayDmrId =/ c gatewayDmrId = ${dmr_id}                  ; ID to use when transmitting from Analog_Bridge" "$file"
	sudo sed -i -e "/^repeaterID =/ c repeaterID = ${rpt_id}                  ; ID of source repeater" "$file"
	sudo sed -i -e "/Transmit USRP/ c txPort = ${usrp_port}                          ; Transmit USRP frames on this port" "$file"
	sudo sed -i -e "/Listen for USRP/ c rxPort = ${usrp_port}                          ; Listen for USRP frames on this port" "$file"
done
#-----------------------------------------------------------
echo "      -----------------------------------------"
mmdvm="/opt/MMDVM_Bridge/"
for file in ${mmdvm}MMDVM_Bridge.ini
do
	sudo sed -i -e "/^Callsign=/ c Callsign=${call_sign}" "${file}"
        sudo sed -i -e "/^RXFrequency/ c RXFrequency=000000000" "${file}"
        sudo sed -i -e "/^TXFrequency/ c TXFrequency=000000000" "${file}"
if [ ${call_sign:0:2} = "HL" ] || [ ${call_sign:0:2} = "DS" ] || [ ${call_sign:0:2} = "6K" ] || [ ${call_sign:0:2} = "6L" ]; then
        sudo sed -i -e "/^RXFrequency/ c RXFrequency=431000000" "${file}"
    	sudo sed -i -e "/^TXFrequency/ c TXFrequency=431000000" "${file}"
       	sudo sed -i -e "/^Latitude/ c Latitude=36.0000" "${file}"
        sudo sed -i -e "/^Longitude/ c Longitude=129.0000" "${file}"
       	sudo sed -i -e "/^Location/ c Location=Korea" "${file}"
        sudo sed -i -e "/^Description=/ c Description=Korea" "${file}"
echo "      -----------------------------------------"
fi
	sudo sed -i -e "/^Enable=/ c Enable=1" "$file"
	sudo sed -i -e "/^Module=/ c Module=${module}" "${file}"
        sudo sed -i -e "/^Password=/ c Password=${bm_password}" "${file}"
	General=$(grep -n "\[General" ${mmdvm}MMDVM_Bridge.ini | cut -d':' -f1)
	id_line=`expr $General + 2`
	sudo sed -i -e "${id_line}s/.*/Id=${rpt_id}/" "${file}"

	NXDN=$(grep -n "\[NXDN\]" ${mmdvm}MMDVM_Bridge.ini | cut -d':' -f1)
	id_line=`expr $NXDN + 3`
        sudo sed -i -e "${id_line}s/.*/Id=${nxdn_id}/" "${file}"

	DMR_Network=$(grep -n "\[DMR Network" ${mmdvm}MMDVM_Bridge.ini | cut -d':' -f1)
        add_line=`expr $DMR_Network + 2`
        sudo sed -i -e "${add_line}s/.*/Address=${bm_address}/" "${file}"

	System_Fusion_Network=$(grep -n "\[System Fusion Network" ${mmdvm}MMDVM_Bridge.ini | cut -d':' -f1)
        add_line=`expr $System_Fusion_Network + 4`
        sudo sed -i -e "${add_line}s/.*/GatewayAddress=ysf.glorb.com/" "${file}"
	port_line=`expr $System_Fusion_Network + 5`
	sudo sed -i -e "${port_line}s/.*/GatewayPort=42000/" "${file}"
done
#-----------------------------------------------------------
echo "      -----------------------------------------"

nxdn="/opt/NXDNGateway/"
for file in ${nxdn}NXDNGateway.ini
do
        sudo sed -i -e "/^Callsign=/ c Callsign=${call_sign}" "${file}"
done
#-----------------------------------------------------------
echo "      -----------------------------------------"
p25="/opt/P25Gateway/"
for file in ${p25}P25Gateway.ini
do
        sudo sed -i -e "/^Callsign=/ c Callsign=${call_sign}" "${file}"
done
#-----------------------------------------------------------
echo "      -----------------------------------------"
ysf="/opt/YSFGateway/"
for file in ${ysf}YSFGateway.ini
do
        sudo sed -i -e "/^Callsign=/ c Callsign=${call_sign}" "${file}"
	sudo sed -i -e "/^Id=/ c Id=${rpt_id}" "$file"
done
#-----------------------------------------------------------
echo "      -----------------------------------------"
#quantar="/opt/Quantar_Bridge/"
#for file in ${quantar}Quantar_Bridge.ini
#do
#        sudo sed -i -e "/^Address =/ c Address = 127.0.0.1             ; Address to send AMBE TLV frames to (export)" "${file}"
#done
#-----------------------------------------------------------
echo "      -----------------------------------------"
etc="/etc/"
for file in ${etc}ircddbgateway
do
        sudo sed -i -e "/^gatewayCallsign=/ c gatewayCallsign=${call_sign}" "${file}"
        sudo sed -i -e "/^repeaterCall1=/ c repeaterCall1=${call_sign}" "${file}"
	sudo sed -i -e "/^repeaterBand1=/ c repeaterBand1=${module}" "${file}"
        sudo sed -i -e "/^ircddbUsername=/ c ircddbUsername=${call_sign}" "${file}"
        sudo sed -i -e "/^ircddbPassword=/ c ircddbPassword=${call_sign}" "${file}"
        sudo sed -i -e "/^dplusEnabled=/ c dplusEnabled=1" "$file"
        sudo sed -i -e "/^dplusLogin=/ c dplusLogin=${call_sign}" "${file}"
        sudo sed -i -e "/^language=/ c language=0" "$file"
        sudo sed -i -e "/^logEnabled=/ c logEnabled=1" "$file"
done
#-----------------------------------------------------------
echo "      -----------------------------------------"

# AMBE

if [ "$ambe_option" = "1" ]; then
        for file in ${AB}Analog_Bridge.ini
        do
          sudo sed -i -e "/IP address of AMBE/ c address = ${ambe_server}               ; IP address of AMBEServer" "$file"
          sudo sed -i -e "/Port of AMBE/ c rxPort = ${ambe_rxport}                         ; Port of AMBEServer" "$file"
          sudo sed -i -e "/Device of DV3000/ c ; address = /dev/ttyUSB0              ; Device of DV3000U on this machine" "$file"
          sudo sed -i -e "/Baud rate/ c ; baud = 460800                       ; Baud rate of the dongle (230400 or 460800)" "$file"
          sudo sed -i -e "/Use serial/ c ; serial = true                       ; Use serial=true for direct connect or serial=false for AMBEServer" "$file"
        done

elif [ "$ambe_option" = "2" ]; then
        for file in ${AB}Analog_Bridge.ini
        do
          sudo sed -i -e "/IP address of AMBE/ c ; address = 127.0.0.1                 ; IP address of AMBEServer" "$file"
          sudo sed -i -e "/Port of AMBE/ c ; rxPort = 2460                       ; Port of AMBEServer" "$file"
          sudo sed -i -e "/Device of DV3000/ c address = /dev/ttyUSB0                ; Device of DV3000U on this machine" "$file"
          sudo sed -i -e "/Baud rate/ c baud = ${ambe_baud}                         ; Baud rate of the dongle (230400 or 460800)" "$file"
          sudo sed -i -e "/Use serial/ c serial = true                         ; Use serial=true for direct connect or serial=false for AMBEServer" "$file"
        done

echo "      -----------------------------------------"

#elif [ "$ambe_option" = "3" ]; then
#        for file in ${AB}Analog_Bridge.ini
#        do
#          sudo sed -i -e "/IP address of AMBE/ c address = 127.0.0.1                   ; IP address of AMBEServer" "$file"
#          sudo sed -i -e "/Port of AMBE/ c ; rxPort = 2460                       ; Port of AMBEServer" "$file"
#          sudo sed -i -e "/Device of DV3000/ c address = /dev/ttyAMA0                ; Device of DV3000U on this machine" "$file"
#          sudo sed -i -e "/Baud rate/ c baud = ${ambe_baud}                         ; Baud rate of the dongle (230400 or 460800)" "$file"
#          sudo sed -i -e "/Use serial/ c serial = true                         ; Use serial=true for direct connect or serial=false for AMBEServer" "$file"
#        done

elif [ "$ambe_option" = "3" ]; then
        for file in ${AB}Analog_Bridge.ini
        do
          sudo sed -i -e "/IP address of AMBE/ c ; address = 127.0.0.1                 ; IP address of AMBEServer" "$file"
          sudo sed -i -e "/Port of AMBE/ c ; rxPort = 2460                       ; Port of AMBEServer" "$file"
          sudo sed -i -e "/Device of DV3000/ c ; address = /dev/ttyUSB0              ; Device of DV3000U on this machine" "$file"
          sudo sed -i -e "/Baud rate/ c ; baud = 460800                       ; Baud rate of the dongle (230400 or 460800)" "$file"
          sudo sed -i -e "/Use serial/ c ; serial = true                       ; Use serial=true for direct connect or serial=false for AMBEServer" "$file"
        done
fi

echo "      -----------------------------------------"

for file in ${DVS}var.txt
do
        sudo sed -i -e "/^call_sign/ c call_sign=\"${call_sign}\"" "${file}"
        sudo sed -i -e "/^dmr_id/ c dmr_id=\"${dmr_id}\"" "${file}"
        sudo sed -i -e "/^rpt_id=/ c rpt_id=\"${rpt_id}\"" "${file}"
	rpt_id_2=$(($rpt_id+10))
        rpt_id_3=$(($rpt_id+20))
        sudo sed -i -e "/^rpt_id_2/ c rpt_id_2=\"${rpt_id_2}\"" "${file}"
        sudo sed -i -e "/^rpt_id_3/ c rpt_id_3=\"${rpt_id_3}\"" "${file}"
        sudo sed -i -e "/^module/ c module=\"${module}\"" "${file}"
        sudo sed -i -e "/^nxdn_id/ c nxdn_id=\"${nxdn_id}\"" "${file}"
        sudo sed -i -e "/^usrp_port/ c usrp_port=\"${usrp_port}\"" "${file}"
        sudo sed -i -e "/^bm_master/ c bm_master=\"${bm_master}\"" "${file}"
        sudo sed -i -e "/^bm_address/ c bm_address=\"${bm_address}\"" "${file}"
        sudo sed -i -e "/^bm_password/ c bm_password=\"${bm_password}\"" "${file}"
        sudo sed -i -e "/^bm_port/ c bm_port=\"${bm_port}\"" "${file}"
        sudo sed -i -e "/^ambe_option/ c ambe_option=\"${ambe_option}\"" "$file"
        sudo sed -i -e "/^ambe_server/ c ambe_server=\"${ambe_server}\"" "$file"
        sudo sed -i -e "/^ambe_rxport/ c ambe_rxport=\"${ambe_rxport}\"" "$file"
        sudo sed -i -e "/^ambe_baud/ c ambe_baud=\"${ambe_baud}\"" "$file"

        sudo sed -i -e "/^bm_address=/ c bm_address=\"${bm_address}\"" "${file}"
        sudo sed -i -e "/^bm_password=/ c bm_password=\"${bm_password}\"" "${file}"
done

echo "      -----------------------------------------"

do_dvsm.macro_copy_to_basic_force() {
       	sudo \mv -f ${AB}dvsm.macro ${AB}dvsm.basic
}

do_macro_file_copy_to_AB() {
        sudo cp ${DVS}ab/*.* ${AB}
#                crontab -l | perl -nle 's/^#\s*([0-9*])/$1/;print' | crontab
#                sudo service cron restart
#                ${DVS}./88_restart.sh
}

do_AB.ini_audio_edit() {
	for file in ${AB}Analog_Bridge.ini
        do
        sudo sed -i -e "/^usrpAudio/ c usrpAudio = AUDIO_USE_GAIN              ; Digital -> Analog (AUDIO_UNITY, AUDIO_USE_GAIN, AUDIO_USE_AGC)" "$file"
        sudo sed -i -e "/^usrpGain/ c usrpGain = ${usrpGain}                         ; Gain factor when usrpAudio = AUDIO_USE_GAIN (0.0 to 5.0) (1.0 = AUDIO_UNITY)" "$file"
        sudo sed -i -e "/^tlvAudio/ c tlvAudio = AUDIO_USE_GAIN               ; Analog -> Digital (AUDIO_UNITY, AUDIO_USE_GAIN, AUDIO_BPF)" "$file"
        sudo sed -i -e "/^tlvGain/ c tlvGain = ${txgain_dmr}                          ; Gain factor when tlvAudio = AUDIO_USE_GAIN (0.0 to 5.0) (1.0 = AUDIO_UNITY)" "$file"
        done
}

# if [there is dvsm.basic] -> Advanced Macro Configuration
if [ -e ${AB}dvsm.basic ]; then
#       if there is not character "Advanced" in dvsm.macro -> updated & upgraded and dvsm.macro is brand new
	char=$(sudo grep -o "Advanced" /opt/Analog_Bridge/dvsm.macro | wc -w)
	if [ $((char)) -lt 1 ];	then do_dvsm.macro_copy_to_basic_force
	fi
	do_macro_file_copy_to_AB
	do_AB.ini_audio_edit
else
	if [ ${call_sign:0:2} = "HL" ] || [ ${call_sign:0:2} = "DS" ] || [ ${call_sign:0:2} = "6K" ] || [ ${call_sign:0:2} = "6L" ] || [ "${lan}" = "KR" ]; then
	do_dvsm.macro_copy_to_basic_force
        do_macro_file_copy_to_AB
        do_AB.ini_audio_edit
	fi
fi
echo "      -----------------------------------------"

#sudo systemctl enable quantar_bridge
sudo systemctl enable mmdvm_bridge
sudo systemctl enable analog_bridge
echo "      -----------------------------------------"
sudo systemctl enable p25gateway
sudo systemctl enable nxdngateway
echo "      -----------------------------------------"
sudo systemctl enable ysfgateway
sudo systemctl enable ircddbgatewayd.service

echo "      -----------------------------------------"

#sudo systemctl start quantar_bridge
sudo systemctl start mmdvm_bridge
sudo systemctl start analog_bridge

echo "      -----------------------------------------"
echo
echo "             Initial Configuration Finished "
echo
echo "======================================================="
}

#-------------------------------------------------------------------------------------------

do_final() {
sleep 2
clear
if (whiptail --title " Initial Configuration Finished " --yesno "\
You can start using after REBOOTing\n
<Yes> to REBOOT, or <No> back to MENU\
" 10 70);
	then sudo reboot
	else ${DVS}baseline_config_menu.sh; exit 0
fi
}
#-------------------------------------------------------------------------------------------

#=======================================================================================#
##-------------------------------------------------------------------------------------##
##                                MAIN PROGRAM                                         ##
##-------------------------------------------------------------------------------------##
#=======================================================================================#

# if init_config.sh starts with "re" argument "init_config.sh re"
if [ "$1" = "re" ]; then
do_change
exit 0
fi

if [ ${call_sign} != "N0CALL" ]; then
if (whiptail --title " Previous Configuration notice" --yesno "\
You already have previous a configuration for ${call_sign}/${dmr_id}

<Yes> to start automatic configuration for ${call_sign}

<No> to start a new configuration
" 12 70); then
	do_change
	do_final
fi
fi


if (whiptail --title " Initial Configuration " --yesno "\
This process will ask you Callsign, DMR ID, USRP port, AMBE... etc.

<Yes> to continue
" 10 70); then :
	else ${DVS}baseline_config_menu.sh; exit 0
fi


call_sign=$(whiptail --title "Input" --inputbox "Callsign ? (Capital letters)" 10 60 ${call_sign} 3>&1 1>&2 2>&3)
if [ $? != 0 ]; then ${DVS}baseline_config_menu.sh; exit 0
fi
#

dmr_id_old=${dmr_id}

dmr_id=$(whiptail --title "Input" --inputbox "CCS7/DMR ID ?" 10 60 ${dmr_id} 3>&1 1>&2 2>&3)
if [ $? != 0 ]; then ${DVS}baseline_config_menu.sh; exit 0
fi
#

if [ ${dmr_id_old} = ${dmr_id} ]; then
rpt_id=$(whiptail --title "Input" --inputbox "CCS7/DMR ID + 2 digit number (00 ~99) ?" 10 60 ${rpt_id} 3>&1 1>&2 2>&3)
else
rpt_id=$(whiptail --title "Input" --inputbox "CCS7/DMR ID + 2 digit number (00 ~99) ?" 10 60 ${dmr_id}11 3>&1 1>&2 2>&3)
fi
if [ $? != 0 ]; then ${DVS}baseline_config_menu.sh; exit 0
fi

if [ ${call_sign:0:2} = "HL" ] || [ ${call_sign:0:2} = "DS" ] || [ ${call_sign:0:2} = "6K" ] || [ ${call_sign:0:2} = "6L" ] || [ "${lan}" = "KR" ]; then
module=$(whiptail --title "Input" --inputbox "Dstar module ? (A~Z) ? " 10 60 ${module} 3>&1 1>&2 2>&3)
if [ $? != 0 ]; then ${DVS}baseline_config_menu.sh; exit 0
fi
fi

#
nxdn_id=$(whiptail --title "Input" --inputbox "NXDN ID ? (Enter for none)" 10 60 ${nxdn_id} 3>&1 1>&2 2>&3)
if [ $? != 0 ]; then ${DVS}baseline_config_menu.sh; exit 0
fi
#
usrp_port=$(whiptail --title "Input" --inputbox "USRP Port ? (50000~55000)" 10 60 ${usrp_port} 3>&1 1>&2 2>&3)
if [ $? != 0 ]; then ${DVS}baseline_config_menu.sh; exit 0
fi
#


value=$(cat ${DVS}bm.list)
num=$(whiptail --title "Local Brandmeister Master Server" --menu "\
\n
      Choose your local BM Server
" 30 42 20 ${value} 3>&1 1>&2 2>&3)

eval "bm_master=\${bm${num}[0]}"
eval "bm_address=\${bm${num}[1]}"
eval "bm_password=\${bm${num}[3]}"
eval "bm_port=\${bm${num}[4]}"


bm_password=$(whiptail --title "Input" --inputbox "Enter your personalized hotspot password configured via Brandmeister SelfCare, if applicable, otherwise leave as default." 10 60 ${bm_password} 3>&1 1>&2 2>&3)
if [ $? != 0 ]; then ${DVS}baseline_config_menu.sh; exit 0
fi

#bm_port=$(whiptail --title "Input" --inputbox "Brandmeister Server Port" 10 60 ${bm_port} 3>&1 1>&2 2>&3)
#if [ $? != 0 ]; then ${DVS}baseline_config_menu.sh; exit 0
#fi


OPTION=$(whiptail --title " Hardware Vocoder (AMBE) " --menu "\
\n
" 12 80 3 \
"1 AMBE Server" "External AMBE Server e.g., ZumAMBE Server" \
"2 USB Type AMBE" "ThumbDV, DVstick" \
"3 NONE" "No Hardware Vocoder" \
3>&1 1>&2 2>&3)

if [ $? != 0 ]; then ${DVS}baseline_config_menu.sh; exit 0
fi

case "$OPTION" in
1\ *)ambe_option="1" ;;
2\ *)ambe_option="2" ;;
3\ *)ambe_option="3" ;;
esac

if [ $? != 0 ]; then ${DVS}baseline_config_menu.sh; exit 0
fi
#----------------------------------------------------------------------------------------------------------------------
if [ $ambe_option = "1" ]; then
        ambe_server=$(whiptail --title " IP address of AMBEServer " --inputbox "IP or DDNS address ?" 8 50 ${ambe_server} 3>&1 1>&2 2>&3)
        if [ $? != 0 ]; then ${DVS}baseline_config_menu.sh; exit 0
        fi

        ambe_rxport=$(whiptail --title " Port of AMBEServer " --inputbox "Port (UDP) ?" 8 50 ${ambe_rxport} 3>&1 1>&2 2>&3)
        if [ $? != 0 ]; then ${DVS}baseline_config_menu.sh; exit 0
        fi

elif [ $ambe_option = "2" ]; then
        ambe_baud=$(whiptail --title " Baudrate of ThumbDV or DVstick " --inputbox "Baudrate ? (460800 or 230400)" 8 50 ${ambe_baud} 3>&1 1>&2 2>&3)
        if [ $? != 0 ]; then ${DVS}baseline_config_menu.sh; exit 0
        fi

#elif [ $ambe_option = "3" ]; then
#        ambe_baud=$(whiptail --title " Baudrate of AMBE Board " --inputbox "Baudrate ? (460800 or 230400)" 8 50 ${ambe_baud} 3>&1 1>&2 2>&3)
#        if [ $? != 0 ]; then ${DVS}baseline_config_menu.sh; exit 0
#        fi

elif [ $ambe_option = "3" ]; then :

fi

#----------------------------------------------------------------------------------------------------------------------

if (whiptail --title " Input Finished " --yesno "\
Input for Initial Configuration Finished.
ini files' configuration will start.

<Yes> to Start, <No> to Cancel
" 10 70);
	then
		clear;
		do_change;
		do_final
	else ${DVS}baseline_config_menu.sh
fi

