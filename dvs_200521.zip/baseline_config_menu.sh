#!/bin/bash


DVS="/usr/local/dvs/"
AB="opt/Analog_Bridge/"
MB="/opt/MMDVM_Bridge/"

source ${DVS}lan/language.txt


OPTION=$(whiptail --title " Baseline Configuration Menu " --menu "\
\n
" 12 90 4 \
"1 Raspberry Pi Configuration " "Seup Wi-Fi, Locale, Timezone and Keyboard layout" \
"2 Initial Configuration" "Enter Callsign, DMR ID, BM Server and AMBE" \
"3 Language" "Change Language" \
"4 Back to MAIN MENU" "Back to MAIN MENU" 3>&1 1>&2 2>&3)

if [ $? != 0 ]; then
	${DVS}dvs; exit 0
fi

case $OPTION in
1\ *)${DVS}rpi_config.sh ;;
2\ *)${DVS}init_config.sh ;;
3\ *)${DVS}language.sh ;;
4\ *)${DVS}dvs; exit 0
esac

clear

exit 0

