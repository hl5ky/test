#!/bin/bash

DVS="/usr/local/dvs/"
AB="/opt/Analog_Bridge/"
MB="/opt/MMDVM_Bridge/"


if [ -e ${AB}dvsm.basic ]; then
${DVS}adhoc_adv.sh

elif [ ! -e ${AB}dvsm.basic ]; then
${DVS}adhoc_basic.sh

fi

exit 0



