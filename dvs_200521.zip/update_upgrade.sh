#!/bin/bash

DVS="/usr/local/dvs/"
AB="/opt/Analog_Bridge/"
MB="/opt/MMDVM_Bridge/"

source ${DVS}lan/language.txt

${DVS}dvs
