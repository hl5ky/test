#!/bin/bash

#------------------------------------------------------------------------------------------
# Excution Script for DVSM.MACRO
# May 15, 2020
# HL5KY
#------------------------------------------------------------------------------------------
#
DVS="/usr/local/dvs/"
AB="/opt/Analog_Bridge/"
MB="/opt/MMDVM_Bridge/"
#------------------------------------------------------------------------------------------

source ${DVS}var.txt

MODE=$(sudo ${MB}dvswitch.sh mode)

#==========================================================================================


#------ RESTART ---------------------------------------------------------------------------
if [ $1 = "restart" ]; then
	${DVS}./88_restart.sh
fi

#------ REBOOT ----------------------------------------------------------------------------
if [ $1 = "reboot" ]; then
	${DVS}./99_reboot.sh
fi

#------ MODE ------------------------------------------------------------------------------

if [ $1 = "dmr" ]; then
        if [ ${MODE} = "DMR" ]; then
        ${MB}dvswitch.sh message "already on   DMR"
        else
        ${MB}dvswitch.sh mode DMR
        ${MB}dvswitch.sh tlvAudio AUDIO_USE_GAIN ${txgain_dmr}
#        sudo systemctl stop ircddbgatewayd
        fi

elif [ $1 = "dstar" ]; then
        if [ ${MODE} = "DSTAR" ]; then
        ${MB}dvswitch.sh message "already on   DSTAR"
#        sudo systemctl restart ircddbgatewayd
        else
#        sudo systemctl restart ircddbgatewayd
#  	sleep 12
        ${MB}dvswitch.sh mode DSTAR
        ${MB}dvswitch.sh tlvAudio AUDIO_USE_GAIN ${txgain_dstar}
        fi

elif [ $1 = "nxdn" ]; then
        if [ ${MODE} = "NXDN" ]; then
        ${MB}dvswitch.sh message "already on   NXDN"
        else
        ${MB}dvswitch.sh mode NXDN
        ${MB}dvswitch.sh tlvAudio AUDIO_USE_GAIN ${txgain_nxdn}
#        sudo systemctl stop ircddbgatewayd
        fi
        ${MB}dvswitch.sh tlvAudio AUDIO_USE_GAIN ${txgain_nxdn}

elif [ $1 = "p25" ]; then
        if [ ${MODE} = "P25" ]; then
        ${MB}dvswitch.sh message "already on   P25"
        else
        ${MB}dvswitch.sh mode P25
        ${MB}dvswitch.sh tlvAudio AUDIO_USE_GAIN ${txgain_p25}
#        sudo systemctl stop ircddbgatewayd
        fi

elif [ $1 = "ysf" ]; then
        if [ ${MODE} = "YSFN" ]; then
        ${MB}dvswitch.sh message "already on   YSF"
        else
        ${MB}dvswitch.sh mode YSF
        ${MB}dvswitch.sh tlvAudio AUDIO_USE_GAIN ${txgain_ysf}
#        sudo systemctl stop ircddbgatewayd
        fi
fi

#------ BM / TGIF / DMRPlus ----------------------------------------------------------------
if [ $1 = "bm" ]; then
	${MB}/dvswitch.sh tune "${bm_password}@${bm_address}:${bm_port}"

elif [ $1 = "tgif" ]; then
	${MB}/dvswitch.sh tune "${tgif_password}@${tgif_address}:${tgif_port}"

elif [ $1 = "dmrplus" ]; then
	${MB}/dvswitch.sh tune "${dmrplus_password}@${dmrplus_address}:${dmrplus_port}"
#	${MB}/dvswitch.sh tune "${dmrplus_password}@${dmrplus_address}:${dmrplus_port}:StartRef=4649;RelinkTime=60;UserLink=1"
fi

#------ Start of tlvAudio ------------------------------------------------------------------

do_set_tlvAudio() {

gain_now=$(sudo ${MB}dvswitch.sh tlvAudio AUDIO_USE_GAIN)

if [ ${cal} = "plus" ]; then
	gain=$(echo "${gain_now} ${gain_change}" | awk '{printf "%.2f", $1+$2}')

elif [ ${cal} = "mnus" ]; then
	gain=$(echo "${gain_now} ${gain_change}" | awk '{printf "%.2f", $1-$2}')

elif [ ${cal} = "cent" ]; then
	gain=${gain_now}
#	${MB}dvswitch.sh message "TX  GAIN   ${gain}"
fi


if [ ${MODE} = "DMR" ]; then
        sudo sed -i -e "/^*tx_c_0.00/ c *tx_c_0.00,DMR TX Gain   <  ${gain}  >" "${AB}TX_gain.txt";
	${MB}dvswitch.sh macro ${AB}TX_gain.txt;
	sudo sed -i -e "/^txgain_dmr=/ c txgain_dmr=\"${gain}\"" "${DVS}var.txt";
        sudo sed -i -e "/^tlvGain/ c tlvGain = ${gain}                          ; Gain factor when tlvAudio = AUDIO_USE_GAIN (0.0 to 5.0) (1.0 = AUDIO_UNITY)" "${AB}Analog_Bridge.ini";

elif [ ${MODE} = "DSTAR" ]; then
        sudo sed -i -e "/^*tx_c_0.00/ c *tx_c_0.00,DSTAR TX Gain   <  ${gain}  >" "${AB}TX_gain.txt";
        ${MB}dvswitch.sh macro ${AB}TX_gain.txt;
        sudo sed -i -e "/^txgain_dstar=/ c txgain_dstar=\"${gain}\"" "${DVS}var.txt";

elif [ ${MODE} = "NXDN" ]; then
        sudo sed -i -e "/^*tx_c_0.00/ c *tx_c_0.00,NXDN TX Gain   <  ${gain}  >" "${AB}TX_gain.txt";
        ${MB}dvswitch.sh macro ${AB}TX_gain.txt;
        sudo sed -i -e "/^txgain_nxdn=/ c txgain_nxdn=\"${gain}\"" "${DVS}var.txt";

elif [ ${MODE} = "P25" ]; then
        sudo sed -i -e "/^*tx_c_0.00/ c *tx_c_0.00,P25 TX Gain   <  ${gain}  >" "${AB}TX_gain.txt";
        ${MB}dvswitch.sh macro ${AB}TX_gain.txt;
        sudo sed -i -e "/^txgain_p25=/ c txgain_p25=\"${gain}\"" "${DVS}var.txt";

elif [ ${MODE} = "YSFN" ]; then
        sudo sed -i -e "/^*tx_c_0.00/ c *tx_c_0.00,YSF TX Gain   <  ${gain}  >" "${AB}TX_gain.txt";
        ${MB}dvswitch.sh macro ${AB}TX_gain.txt;
        sudo sed -i -e "/^txgain_ysf=/ c txgain_ysf=\"${gain}\"" "${DVS}var.txt";
fi

${MB}dvswitch.sh tlvAudio AUDIO_USE_GAIN ${gain}
}

#------ Main of tlvAudio ---------------------------------------------------------------------------
  if [ $1 = "tx_p_0.20" ]; then cal="plus"; gain_change="0.20"; do_set_tlvAudio
elif [ $1 = "tx_p_0.15" ]; then cal="plus"; gain_change="0.15"; do_set_tlvAudio
elif [ $1 = "tx_p_0.10" ]; then cal="plus"; gain_change="0.10"; do_set_tlvAudio
elif [ $1 = "tx_p_0.05" ]; then cal="plus"; gain_change="0.05"; do_set_tlvAudio
elif [ $1 = "tx_c_0.00" ] || [ $1 = "tx_gain" ]; then cal="cent"; do_set_tlvAudio
elif [ $1 = "tx_m_0.05" ]; then cal="mnus"; gain_change="0.05"; do_set_tlvAudio
elif [ $1 = "tx_m_0.10" ]; then cal="mnus"; gain_change="0.10"; do_set_tlvAudio
elif [ $1 = "tx_m_0.15" ]; then cal="mnus"; gain_change="0.15"; do_set_tlvAudio
elif [ $1 = "tx_m_0.20" ]; then cal="mnus"; gain_change="0.20"; do_set_tlvAudio
fi
#------ End of tlvAudio -----------------------------------------------------------------------------

#------ Start of usrpAudio ---------------------------------------------------------------------------

do_set_usrpAudio() {
        sudo sed -i -e "/^*rx_0.00/ c *rx_0.00,Current RX Gain   <  ${gain}  >" "${AB}RX_gain.txt";
        ${MB}dvswitch.sh macro ${AB}RX_gain.txt;
        ${MB}dvswitch.sh usrpAudio AUDIO_USE_GAIN ${gain}
        sudo sed -i -e "/^usrpGain=/ c usrpGain=\"${gain}\"" "${DVS}var.txt";
        sudo sed -i -e "/^usrpGain/ c usrpGain = ${gain}                         ; Gain factor when usrpAudio = AUDIO_USE_GAIN (0.0 to 5.0) (1.0 = AUDIO_UNITY)" "${AB}Analog_Bridge.ini"
}

  if [ $1 = "rx_gain" ]; then gain=$(sudo ${MB}dvswitch.sh usrpAudio AUDIO_USE_GAIN); do_set_usrpAudio
elif [ $1 = "rx_0.00" ]; then gain=$(sudo ${MB}dvswitch.sh usrpAudio AUDIO_USE_GAIN); do_set_usrpAudio
elif [ $1 = "rx_1.00" ]; then gain="1.00"; do_set_usrpAudio
elif [ $1 = "rx_2.00" ]; then gain="2.00"; do_set_usrpAudio
elif [ $1 = "rx_3.00" ]; then gain="3.00"; do_set_usrpAudio
elif [ $1 = "rx_4.00" ]; then gain="4.00"; do_set_usrpAudio
elif [ $1 = "rx_5.00" ]; then gain="5.00"; do_set_usrpAudio
elif [ $1 = "rx_6.00" ]; then gain="6.00"; do_set_usrpAudio
elif [ $1 = "rx_7.00" ]; then gain="7.00"; do_set_usrpAudio
elif [ $1 = "rx_8.00" ]; then gain="8.00"; do_set_usrpAudio
elif [ $1 = "rx_9.00" ]; then gain="9.00"; do_set_usrpAudio
elif [ $1 = "rx_10.0" ]; then gain="10.0"; do_set_usrpAudio
fi
#------ End of usrpAudio -----------------------------------------------------------------------------

exit 0
