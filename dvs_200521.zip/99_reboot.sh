#!/bin/bash

#sudo systemctl enable quantar_bridge
sudo systemctl enable mmdvm_bridge
sudo systemctl enable analog_bridge
sudo systemctl enable p25gateway
sudo systemctl enable nxdngateway
sudo systemctl enable ysfgateway
sudo systemctl enable ircddbgatewayd.service

sudo reboot
