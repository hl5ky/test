#!/bin/bash

#sudo systemctl restart quantar_bridge
sudo systemctl restart mmdvm_bridge
sudo systemctl restart analog_bridge
#sudo systemctl restart p25gateway
#sudo systemctl restart nxdngateway
#sudo systemctl restart ysfgateway
#sudo systemctl restart ircddbgatewayd.service



