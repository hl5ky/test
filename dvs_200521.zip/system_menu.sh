#!/bin/bash


DVS="/usr/local/dvs/"
AB="opt/Analog_Bridge/"
MB="/opt/MMDVM_Bridge/"

source ${DVS}lan/language.txt

#------ do_restart_service() -----------------------------------------------------------------------------
do_restart_service() {

clear
echo
echo
echo "          ----------------------------------"
echo
echo "              DVSwitch Services Restarting"
echo
sleep 1
echo
echo
echo
echo "              Finished,  Back to the MENU"
echo
echo "                       QRX one"
echo "====================================================="
echo
${DVS}88_restart.sh
clear
${DVS}system_menu.sh; exit 0
}



OPTION=$(whiptail --title " System Control Menu " --menu "\
\n
" 12 90 4 \
"1 Restart DVSwitch Services " "Restart Analog & MMDVM Services (2sec)" \
"2 Reboot RPi Server" "Reboot Raspberry Pi Server (30sec)" \
"3 Shutdown RPi Server" "Shutdown Raspberry Pi"  \
"4 Back to MAIN MENU" "Back to MAIN MENU" 3>&1 1>&2 2>&3)

if [ $? != 0 ]; then
        ${DVS}dvs; exit 0
fi

case $OPTION in
1\ *)do_restart_service ;;
2\ *)sudo reboot ;;
3\ *)sudo shutdown -r now ;;
4\ *)${DVS}dvs; exit 0 ;;
esac

clear

exit 0

