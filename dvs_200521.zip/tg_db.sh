#!/bin/bash

DVS="/usr/local/dvs/"
AB="/opt/Analog_Bridge/"
MB="/opt/MMDVM_Bridge/"
tg_db="/usr/local/dvs/tg_db/"

source ${DVS}lan/language.txt


#================= collectFiles =================
do_get() {

if (whiptail --title " Update Global Node List " --yesno "\
               Update Global Node List

                  <Yes> to continue
" 10 60); then :
	else ${DVS}./tg_db.sh; exit 0
fi

/opt/Analog_Bridge/./dvswitch.sh collectProcessDataFiles
sudo \cp -f /tmp/DMR_node_list.txt ${tg_db}
sudo \cp -f /tmp/DSTAR_node_list.txt ${tg_db}
sudo \cp -f /tmp/NXDN_node_list.txt ${tg_db}
sudo \cp -f /tmp/P25_node_list.txt ${tg_db}
sudo \cp -f /tmp/YSF_node_list.txt ${tg_db}

clear
${DVS}./tg_db.sh; exit 0
}


#================= File Editing =================

do_edit() {




sel2=$(whiptail --title " Edit Favorite DB " --menu "\
\n
    SAVE  : Ctrl-X >> Y >> Enter
    CANCEL: Ctrl-X >> N
" 17 42 6 \
"1" "DMR" \
"2" "DSTAR" \
"3" "NXDN" \
"4" "P25" \
"5" "YSF" \
"6" "Back" \
3>&1 1>&2 2>&3)

if [ $? != 0 ]; then ${DVS}tg_db.sh; exit 0
fi


case $sel2 in
1)
sudo nano ${tg_db}DMR_fvrt_list.txt; do_edit ;;
2)
sudo nano ${tg_db}DSTAR_fvrt_list.txt; do_edit ;;
3)
sudo nano ${tg_db}NXDN_fvrt_list.txt; do_edit ;;
4)
sudo nano ${tg_db}P25_fvrt_list.txt; do_edit ;;
5)
sudo nano ${tg_db}YSF_fvrt_list.txt; do_edit ;;
6)
${DVS}tg_db.sh; exit 0 ;;
esac
}


push_result_msg() {
whiptail --msgbox "\

                      Finished

                     Back to Menu

" 10 60 1
}

#================= PUSH to DVSM =================

do_push() {

sel3=$(whiptail --title " Push to DVSM/UC " --menu "\
\n
" 14 32 6 \
"1" "DMR" \
"2" "DSTAR" \
"3" "NXDN" \
"4" "P25" \
"5" "YSF" \
"6" "Back" \
3>&1 1>&2 2>&3)

if [ $? != 0 ]; then ${DVS}tg_db.sh; exit 0
fi


do_pushtodvsm() {

if (whiptail --title " Push to DVSM/UC " --yesno "\
      PUSH (Favorite DB + Global DB)

      Make sure you read <...success> on DVSM/UC

      <Yes> to continue
" 12 60); then :
        else do_push
fi
}

case $sel3 in

1)
do_pushtodvsm;
sudo sed 1d ${tg_db}DMR_node_list.txt > /tmp/DMR_temp_list.txt;
cat ${tg_db}DMR_fvrt_list.txt /tmp/DMR_temp_list.txt > /tmp/DMR_node_list.txt;
sudo ${MB}dvswitch.sh pushfile /tmp/DMR_node_list.txt;
push_result_msg; do_push ;;
2)
do_pushtodvsm;
sudo sed 1d ${tg_db}DSTAR_node_list.txt > /tmp/DSTAR_temp_list.txt;
cat ${tg_db}DSTAR_fvrt_list.txt /tmp/DSTAR_temp_list.txt > /tmp/DSTAR_node_list.txt;
sudo ${MB}dvswitch.sh pushfile /tmp/DSTAR_node_list.txt;
push_result_msg; do_push ;;
3)
do_pushtodvsm;
sudo sed 1d ${tg_db}NXDN_node_list.txt > /tmp/NXDN_temp_list.txt;
cat ${tg_db}NXDN_fvrt_list.txt /tmp/NXDN_temp_list.txt > /tmp/NXDN_node_list.txt;
sudo ${MB}dvswitch.sh pushfile /tmp/NXDN_node_list.txt;
push_result_msg; do_push ;;
4)
do_pushtodvsm;
sudo sed 1d ${tg_db}P25_node_list.txt > /tmp/P25_temp_list.txt;
cat ${tg_db}P25_fvrt_list.txt /tmp/P25_temp_list.txt > /tmp/P25_node_list.txt;
sudo ${MB}dvswitch.sh pushfile /tmp/P25_node_list.txt;
push_result_msg; do_push ;;
5)
do_pushtodvsm;
sudo sed 1d ${tg_db}YSF_node_list.txt > /tmp/YSF_temp_list.txt;
cat ${tg_db}YSF_fvrt_list.txt /tmp/YSF_temp_list.txt > /tmp/YSF_node_list.txt;
sudo ${MB}dvswitch.sh pushfile /tmp/YSF_node_list.txt;
push_result_msg; do_push ;;
6)
${DVS}tg_db.sh; exit 0 ;;
esac
}


#================= Managing DB =================

sel=$(whiptail --title " TG/Ref DB Management " --menu "\
\n
" 12 90 4 \
"1 Update Global DB" "collectProcessDataFiles, Update Global Node_list" \
"2 Edit Favorite DB" "Edit Your own (saved) Favorite Node_list" \
"3 Push DB to DVSM/UC " "Push (Global Node_list + Edited Favorite Node_list)" \
"4 Back" "Back to Advanced Configuration Menu" \
3>&1 1>&2 2>&3)

if [ $? != 0 ]; then ${DVS}adv_config_menu.sh; exit 0
fi


case $sel in
1\ *)do_get ;;
2\ *)do_edit ;;
3\ *)do_push ;;
4\ *)${DVS}adv_config_menu.sh; exit 0
esac

clear

exit 0
