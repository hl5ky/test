#!/bin/bash


DVS="/usr/local/dvs/"
AB="opt/Analog_Bridge/"
MB="/opt/MMDVM_Bridge/"

source ${DVS}lan/language.txt


OPTION=$(whiptail --title " Advanced Configuration Menu " --menu "\
\n
" 13 90 5 \
"1 Configure ini. files" "Analog_Bridge.ini, MMDVM_Bridge.ini...... Files" \
"2 Configure Favorite TG/Ref " "Edit Favorite TGs and Reflectors, Push to DVSM/UC"  \
"3 Adhoc Menu & Macro" "Managing Adhoc Menu and Macro" \
"4 Additional DMR Networks" "Enter address/port for DMR Plus and TGIF" \
"5 Back to MAIN MENU" "Back to MAIN MENU" 3>&1 1>&2 2>&3)

if [ $? != 0 ]; then
	sudo ${DVS}dvs; exit 0
fi

case $OPTION in
1\ *)sudo ${DVS}config_ini.sh ;;
2\ *)sudo ${DVS}tg_db.sh ;;
3\ *)sudo ${DVS}adhoc_check.sh ;;
4\ *)sudo ${DVS}adnl_dmr.sh ;;
5\ *)sudo ${DVS}dvs; exit 0 ;;
esac

clear

exit 0

